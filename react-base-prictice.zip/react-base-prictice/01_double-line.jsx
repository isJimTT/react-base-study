import React, { Component } from 'react';

class NumberList extends Component {
  render() {
    const { numbers } = this.props;
    return (
      <ul>
        {numbers.map((number, index) => (
          <li 
            key={index} 
            style={{ backgroundColor: index % 2 === 0 ? '#f0f0f0' : '#d0d0d0' }}
          >
            {number}
          </li>
        ))}
      </ul>
    );
  }
}

export default NumberList;