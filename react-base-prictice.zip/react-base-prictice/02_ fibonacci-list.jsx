import React from 'react';

class FibonacciList extends React.Component {
  state = {
    a: 0,
    b: 1,
    list: [0, 1],
  };

  constructor() {
    setInterval(() => {
      this.setState((prevState) => {
        const nextNumber = prevState.a + prevState.b;
        return {
          a: prevState.b,
          b: nextNumber,
          list: [...prevState.list, nextNumber],
        };
      });
    }, 1000);
  }

  render() {
    return <p>{this.state.list.join(', ')}</p>;
  }
}

export default FibonacciList;
