import React, { Component } from 'react';
import NumberList from './NumberList';

class App extends Component {
  constructor() {
    this.state = {
      numbers: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
      oddColor: '#d0d0d0',
      evenColor: '#f0f0f0',
    };
  }

  deepenOddColor = () => {
    this.setState((prevState) => ({
      oddColor: this.darkenColor(prevState.oddColor),
    }));
  };

  deepenEvenColor = () => {
    this.setState((prevState) => ({
      evenColor: this.darkenColor(prevState.evenColor),
    }));
  };

  resetColors = () => {
    this.setState({
      oddColor: '#d0d0d0',
      evenColor: '#f0f0f0',
    });
  };

  darkenColor = (color) => {
    let colorValue = parseInt(color.slice(1), 16);
    colorValue = Math.max(0, colorValue - 0x202020);
    return `#${colorValue.toString(16).padStart(6, '0')}`;
  };

  render() {
    const { numbers, oddColor, evenColor } = this.state;
    return (
      <div>
        <NumberList numbers={numbers} oddColor={oddColor} evenColor={evenColor} />
        <button onClick={this.deepenOddColor}>加深奇数行颜色</button>
        <button onClick={this.deepenEvenColor}>加深偶数行颜色</button>
        <button onClick={this.resetColors}>重置颜色</button>
      </div>
    );
  }
}

export default App;
