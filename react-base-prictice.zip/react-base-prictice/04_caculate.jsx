import React from 'react';
import './calculator.scss'

const STEP = {
    NUMBER_1: 1,
    NUMBER_2: 2,
};

const BTN_TYPE = {
    CTRL: 'ctrl',
    EXP: 'exp',
    NUMBER: 'num',
};

const CTRL = {
    CLEAR: 'C',
    NEGATIVE: '+/-',
    PERCENT: '%',
};

const EXP = {
    PLUS: '+',
    MINUS: '-',
    MULTIPLY: '×',
    DEVIDE: '÷',
};

const NumberBtn = props => {
    return (
        <a
            className={`block block--num ${props.className}`}
            onClick={() => props.onClick(props.num)}
        >
            {props.num}
        </a>
    );
};

NumberBtn.defaultProps = {
    className: '',
};

const CtrlBtn = props => {
    return (
        <a className="block block--ctrl" onClick={() => props.onClick(props.type)}>
            {props.type}
        </a>
    );
};

const ExpBtn = props => {
    return (
        <a className="block block--exp" onClick={() => props.onClick(props.type)}>
            {props.type}
        </a>
    );
};

const CommonBtn = props => {
    const { type, value, className } = props;
    return (
        <a
            className={`block block--${type} ${className}`}
            onClick={() => props.onClick(type, value)}
        >
            {value}
        </a>
    );
};

class Caculator extends React.Component {
    state = this.getInitialState();

    getInitialState() {
        return {
            number1: '',
            exp: '',
            number2: '',
            step: STEP.NUMBER_1,
        };
    }

    getCurrentStepNumber = () => {
        const { step, number1, number2 } = this.state;
        return step === STEP.NUMBER_1 ? number1 : number2;
    };

    setCurrentStepNumber = number => {
        const { step } = this.state;
        this.setState({ [step === STEP.NUMBER_1 ? 'number1' : 'number2']: number });
    };

    onChangeNumber = num => {
        if (this.isEnd) this.setCurrentStepNumber('')
        const { exp, number1, number2, step } = this.state;
        if (exp === '') {
            this.setState(prevState => ({
                number1: prevState.number1 + num + '',
                step: STEP.NUMBER_1,
            }));
        } else if (exp !== '' && number1) {
            this.setState(prevState => ({
                number2: prevState.number2 + num + '',
                step: STEP.NUMBER_2,
            }));
        }
    };
    onChangeExp = exp => {
        this.setState({ exp });
    };
    onBtnClick = (type, value) => {

    };
    onGetResult = () => {
        const { number1, number2, exp } = this.state;
        let result;
        const num1 = parseFloat(number1);
        const num2 = parseFloat(number2);

        switch (exp) {
            case EXP.PLUS:
                result = num1 + num2;
                break;
            case EXP.MINUS:
                result = num1 - num2;
                break;
            case EXP.MULTIPLY:
                result = num1 * num2;
                break;
            case EXP.DEVIDE:
                result = num1 / num2;
                break;
            default:
                result = num1;
                break;
        }
        this.setCurrentStepNumber(result)
        this.state = this.getInitialState()
    };

    onCtrl = type => {
        if (type === CTRL.CLEAR) {
            // TODO
        }
        if (type === CTRL.NEGATIVE) {
            // TODO
            return;
        }
        if (type === CTRL.PERCENT) {
            // TODO
        }
    };

    render() {
        const { number1, number2 } = this.state;

        let number = this.getCurrentStepNumber();
        if (STEP.NUMBER_2 && number2 === '') {
            number = number1;
        }

        return (
            <>
                <div className="caculator">
                    <div className="result-table">{number}</div>
                    <div className="operation-table">
                        <CtrlBtn type={CTRL.CLEAR} onClick={this.onCtrl} />
                        <CtrlBtn type={CTRL.NEGATIVE} onClick={this.onCtrl} />
                        <CtrlBtn type={CTRL.PERCENT} onClick={this.onCtrl} />
                        <ExpBtn type={EXP.DEVIDE} onClick={this.onChangeExp} />
                        <NumberBtn num={7} onClick={this.onChangeNumber} />
                        <NumberBtn num={8} onClick={this.onChangeNumber} />
                        <NumberBtn num={9} onClick={this.onChangeNumber} />
                        <ExpBtn type={EXP.MULTIPLY} onClick={this.onChangeExp} />
                        <NumberBtn num={4} onClick={this.onChangeNumber} />
                        <NumberBtn num={5} onClick={this.onChangeNumber} />
                        <NumberBtn num={6} onClick={this.onChangeNumber} />
                        <ExpBtn type={EXP.MINUS} onClick={this.onChangeExp} />
                        <CommonBtn
                            value={1}
                            type={BTN_TYPE.NUMBER}
                            onClick={this.onBtnClick}
                        />
                        <NumberBtn num={2} onClick={this.onChangeNumber} />
                        <NumberBtn num={3} onClick={this.onChangeNumber} />
                        <ExpBtn type={EXP.PLUS} onClick={this.onChangeExp} />
                        <NumberBtn
                            className="block--double"
                            num={0}
                            onClick={this.onChangeNumber}
                        />
                        <NumberBtn num={'.'} onClick={this.onChangeNumber} />
                        <a className="block block--exp" onClick={this.onGetResult}>
                            =
                        </a>
                    </div>
                </div>
            </>
        );
    }
}

export default Caculator;